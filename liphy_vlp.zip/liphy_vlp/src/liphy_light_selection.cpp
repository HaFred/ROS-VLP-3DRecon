#include <ros/ros.h>
#include <liphy_vlp/liphylight.h>
#include <iostream>
#include "yaml-cpp/yaml.h"
#include <string>
#include "geometry_msgs/PoseWithCovarianceStamped.h"
#include <typeinfo>

using namespace std;

ros::Publisher pub;

void lightCallback(const liphy_vlp::liphylight msg)
{
    geometry_msgs::PoseWithCovarianceStamped pose;
    float pos_x = 0.0;
    float pos_y = 0.0;
    float theta = 0.0;
    YAML::Node lights = YAML::LoadFile("/home/liphy/catkin_ws/src/liphy_vlp/lights/lights.yaml");
    YAML::Node map = YAML::LoadFile("/home/liphy/map/3.yaml");
    float x_cor = map["origin"][0].as<float>();
    float y_cor = map["origin"][1].as<float>();
    // cout << x_cor << "\t" << y_cor << endl;

    for (int i = 1; i <= lights["Lights"]["numLights"].as<int>(); i++)
    {
        // cout << typeid(lights["Lights"]["Light " + to_string(i)]["keypoint"].as<int>()).name() << endl;
        // cout << typeid(stoi(msg.keypoint)).name() << endl;

        // cout << (lights["Lights"]["Light " + to_string(i)]["keypoint"].as<int>() == stoi(msg.keypoint)) << endl;
        //cout << msg.keypoint << endl;
        if(msg.keypoint != "" && lights["Lights"]["Light " + to_string(i)]["keypoint"].as<int>() == stoi(msg.keypoint)){

            pos_x = lights["Lights"]["Light " + to_string(i)]["pos_x"].as<float>();
            pos_y = lights["Lights"]["Light " + to_string(i)]["pos_y"].as<float>();
            theta = msg.theta;

        }
    }
    
    pos_x = x_cor - pos_x;
    pos_y = y_cor - pos_y;

    pos_x += msg.light_x;
    pos_y += msg.light_y;

    pose.header.frame_id = "map";
    pose.header.stamp = ros::Time::now();

    pose.pose.pose.position.x = pos_x;
    pose.pose.pose.position.y = pos_y;
    pose.pose.pose.position.z = 0.0;

    pose.pose.pose.orientation.x = 0.0;
    pose.pose.pose.orientation.y = 0.0;
    pose.pose.pose.orientation.z = 0.0;
    pose.pose.pose.orientation.w = 1.0;
    pose.pose.covariance = {0.7223, 0.0927, 0.117, 0.0, 0.0, 0.1171, 0.0927, 1.1779, -0.2214, 0.0, 0.0, 0.4157, 0.177, -0.2214, 9.0631, 0.0, 0.0, 0.5067, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.1171, 0.4157, 0.5067, 0.0, 0.0, 3.4576};

    
    pub.publish(pose);
    
    
    
    cout << "Keypoint: " << msg.keypoint << endl;
    cout << "Corners: " << msg.corners << endl;
    cout << "Light_x: " << msg.light_x << endl;
    cout << "Light_y: " << msg.light_y << endl;
    cout << "Light_z: " << msg.light_z << endl;
    cout << "Theta: " << msg.theta << endl;

}


int main(int argc, char** argv)
{
    ros::init(argc, argv, "liphy_light_selection");
    ros::NodeHandle nh;
    pub = nh.advertise<geometry_msgs::PoseWithCovarianceStamped>("slovlp_ekf_info_tmp", 1);
    ros::Subscriber lls_subscriber = nh.subscribe("liphy_vlp_info", 1, lightCallback);
    ros::spin();
    return 0;
}